import logging
import boto3
import os
from atlassian import Confluence
import json

 

logger = logging.getLogger()

logger.setLevel(logging.INFO)

 

s3 = boto3.client('s3')

#generic form to split a string into halves on the nth occurence
def split(strng, sep, pos):
    strng = strng.split(sep)
    return sep.join(strng[:pos]), sep.join(strng[pos:])
    

class Helper:
    """
    The options of the function.
    """
    helper = ""
    space = ""
    content = ""
    filename = ""
    parentId = ""


    def __init__(self, environment, content, filename):
        """
        Initializes based on the given environment.
        You can pass os.environ as the argument.
        """
        session = boto3.session.Session()
        
        #get the secret manager
        self.client = session.client(
            service_name='secretsmanager',
            region_name=environment['region']
        )
        
        #get the stored secret
        get_secret_value_response = self.client.get_secret_value(
            SecretId=environment['secretname']
        )
        
        #load the secret into a readable json
        secrets = json.loads(get_secret_value_response['SecretString'])
        
        #initialise the confluence object based on the provided user and url
        self.helper = Confluence(url=secrets['url'], username=secrets['username'], password=secrets['password'])
        self.space = environment['confluencekey']
        self.parentId = environment['parentpage']
        
        #create the macro which should be added on the confluencepage
        self.content = (f'<ac:structured-macro ac:name="code" ac:schema-version="1" ac:macro-id="da03348c-8422-486e-a90e-28f068f37230">'
            f'<ac:parameter ac:name="language">groovy</ac:parameter>'
            f'<ac:plain-text-body><![CDATA[{content}'
            ']]></ac:plain-text-body></ac:structured-macro>'
        )
                
        #remove docu_ and .groovy and trim the withespaces
        self.filename = filename.split("_")[1].split(".")[0].strip()
       

def checkpageaction(Helper):
    
    if Helper.helper.page_exists(Helper.space, Helper.filename):
        updatePage(Helper)
    else:
        createPage(Helper)
    

def updatePage(Helper):
    
    #get the pageId of the existing page
    pageId = Helper.helper.get_page_id(Helper.space, Helper.filename)
    
    #get the content of the page
    pageContent = json.loads(json.dumps(Helper.helper.get_page_by_id(pageId, expand='body.view')))["body"]["view"]["value"]


    #update the page
    status = Helper.helper.update_page(
    page_id=pageId,
    title=Helper.filename,
    body=Helper.content,
    parent_id=Helper.parentId,
    type='page',
    representation='storage',
    minor_edit=False)
    
    print(status)
    
    
def createPage(Helper):
    
    #create the confluence page
    status = Helper.helper.create_page(
    space=Helper.space,
    title=Helper.filename,
    parent_id=Helper.parentId,
    body=Helper.content)

    print(status)
    
    
def lambda_handler(event, context):

    content = ''

    # retrieve bucket name and file_key from the S3 event

    bucket_name = event['Records'][0]['s3']['bucket']['name']

    file_key = event['Records'][0]['s3']['object']['key']

    logger.info('Reading {} from {}'.format(file_key, bucket_name))

    # get the object

    obj = s3.get_object(Bucket=bucket_name, Key=file_key)

    # get lines inside the csv

    lines = obj['Body'].read().split(b'\n')

    for r in lines:
       content = content + r.decode()

    #Initialise the Helper object and check whether to create a new page or update existing one
    checkpageaction(Helper(os.environ, content, file_key))
    
    