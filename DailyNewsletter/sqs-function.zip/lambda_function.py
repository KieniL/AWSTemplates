import os
import boto3
from botocore.exceptions import ClientError

# Replace sender@example.com with your "From" address.
# This address must be verified with Amazon SES.
SENDER = "Sender Name <" +  os.environ['senderName'] + ">"


# The subject line for the email.
SUBJECT = "Your Newsletter"

# The email body for recipients with non-HTML email clients.
BODY_TEXT = ("There is a new Newsletterr")
            
# The HTML body of the email.
BODY_HTML = """<html>
<head></head>
<body>
  <h1>There is a new Newsletter</h1>
</body>
</html>
            """            

# The character encoding for the email.
CHARSET = "UTF-8"


region_name=os.environ['region']

       
# Create a new SES resource and specify a region.
client = boto3.client('ses',region_name=region_name)

def lambda_handler(event, context):
    for record in event['Records']:
        RECIPIENT=str(record["body"])
        print(RECIPIENT)
        print(SENDER)
        # Try to send the email.
        try:
            #Provide the contents of the email.
            response = client.send_email(
                Destination={
                    'ToAddresses': [
                        RECIPIENT,
                    ],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': CHARSET,
                            'Data': BODY_HTML,
                        },
                        'Text': {
                            'Charset': CHARSET,
                            'Data': BODY_TEXT,
                        },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                    },
                },
                Source=SENDER
            )
        # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])

